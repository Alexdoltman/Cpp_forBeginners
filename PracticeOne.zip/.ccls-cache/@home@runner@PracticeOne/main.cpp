
#include <clocale>
#include <cmath>
#include <cstdlib>
#include <ios>
#include <iostream>
using namespace std;

int main() 
{
  setlocale(LC_ALL, "Rus");
  
  ios_base::sync_with_stdio(false);
  
  int  digit;
  
  cout << "Введите число: ";
  
  cin >> digit;
  
    do
    {
      cout << "Вводите число: ";
      cin >> digit;
      if(digit < 0 or !digit) break; // Пользователь случайно может ввести число меньше нуля или нечисло, то тогда программа завершится.
      if(digit == 100) // А если пользователь выиграл, то я поздравлю его: Молодец, друг! Ты - гений! наслаждайтесь.
        cout << "Вы победили! Я поздравляю вас. " << endl;
      else if(digit > 100)
      {
        cout << digit % 100 << endl;
        if(digit > 1000)
        {
          cout << digit % 1100 << endl;
        }
      }
      
    } 
    while(digit != 100);
  
  system("pause");
  
  return 0;
  
}